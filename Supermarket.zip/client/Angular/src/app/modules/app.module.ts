import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { NgReduxModule, NgRedux } from "ng2-redux";
import { AppRoutingModule } from './app-routing.module';
import { LayoutComponent } from '../components/layout/layout.component';
import { LoginComponent } from '../components/login/login.component';
import { FormsModule} from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { Store } from '../redux/store';
import { Reducer } from '../redux/reducer';
import { RegisterComponent } from '../components/register/register.component';
import { Page404Component } from '../components/page404/page404.component';

import { BrowserAnimationsModule } from "@angular/platform-browser/animations";
import { MatInputModule, MatButtonModule, MatCheckboxModule, MatSelectModule, MatFormFieldModule, MatIconModule } from "@angular/material";
import { AboutComponent } from '../components/about/about.component';
import { GeneralInfoComponent } from '../components/general-info/general-info.component';
import { HeaderComponent } from '../components/header/header.component';
import { HomeComponent } from '../components/home/home.component';
import { LoginService } from '../services/login.service';
import { CustomerStatusComponent } from '../components/customer-status/customer-status.component';
import { ShoppingComponent } from '../components/shopping/shopping.component';
import { ItemComponent } from '../components/item/item.component';
import { ProductComponent } from '../components/product/product.component';
import {MatSidenavModule} from '@angular/material/sidenav';

import {MatDialogModule} from '@angular/material/dialog';
import { DialogPopupComponent } from '../components/dialog-popup/dialog-popup.component';
import { MyCartComponent } from '../components/my-cart/my-cart.component';
import { ProductsForShoppingComponent } from '../components/products-for-shopping/products-for-shopping.component';
import { OrderComponent } from '../components/order/order.component';
import { OrderDetailsComponent } from '../components/order-details/order-details.component';
import { DialogAfterOrderComponent } from '../components/dialog-after-order/dialog-after-order.component';
import { AdminComponent } from '../components/admin/admin.component';
import { ProductsManagementComponent } from '../components/products-management/products-management.component';
import { AdminService } from '../services/admin.service';
import {MatToolbarModule} from '@angular/material';
import { ContactUsComponent } from '../components/contact-us/contact-us.component';





@NgModule({
    declarations: [

        LayoutComponent, LoginComponent, RegisterComponent, Page404Component, AboutComponent, GeneralInfoComponent, HeaderComponent, HomeComponent, CustomerStatusComponent, ShoppingComponent, ItemComponent, ProductComponent, DialogPopupComponent, MyCartComponent, ProductsForShoppingComponent, OrderComponent, OrderDetailsComponent, DialogAfterOrderComponent, AdminComponent, ProductsManagementComponent, ContactUsComponent,
    ],
    imports: [
        BrowserModule,
        AppRoutingModule,
        NgReduxModule,
        FormsModule, HttpClientModule,
        
        //   material UI
        BrowserAnimationsModule, MatInputModule, MatButtonModule, MatCheckboxModule, MatSelectModule, MatFormFieldModule,
        MatToolbarModule,
        MatIconModule,
        //Sidenav
        MatSidenavModule,

        MatDialogModule
    ],
    entryComponents: [DialogPopupComponent, DialogAfterOrderComponent],
    providers: [],
    bootstrap: [LayoutComponent]
})
export class AppModule {
    public constructor(redux: NgRedux<Store>, private loginService:LoginService, private adminService:AdminService) {
        redux.configureStore(Reducer.reduce, new Store());

        if (localStorage.getItem("customerDetails")){
            const customerDetails = JSON.parse(localStorage.getItem("customerDetails"));
            this.loginService.login(customerDetails).subscribe((customer) => {
                if (customer !== null) {
                    this.loginService.isLoggedIn(customer);
                }
                else {
                    alert("wrong email or password");
                }
            }, (err) => {
                alert(err.message + ". status:" + err.status + ", " + err.error.message);
            });
        }

        if (localStorage.getItem("adminDetails")){
            const adminDetails = JSON.parse(localStorage.getItem("adminDetails"));
            this.adminService.getAdminDetails(adminDetails).subscribe((admin) => {
                if (admin !== null) {
                    this.adminService.isAdminLoggedIn(admin);
                }
                else {
                    alert("wrong email or password");
                }
            }, (err) => {
                alert(err.message + ". status:" + err.status + ", " + err.error.message);
            });
        }

    }
}
