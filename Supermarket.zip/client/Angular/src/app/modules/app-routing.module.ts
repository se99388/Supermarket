import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LoginComponent } from '../components/login/login.component';
import { Page404Component } from '../components/page404/page404.component';
import { LayoutComponent } from '../components/layout/layout.component';
import { HomeComponent } from '../components/home/home.component';
import { CustomerStatusComponent } from '../components/customer-status/customer-status.component';
import { LoginGuardService } from '../services/login-guard.service';
import { AboutComponent } from '../components/about/about.component';
import { RegisterComponent } from '../components/register/register.component';
import { ShoppingComponent } from '../components/shopping/shopping.component';
import { ProductsForShoppingComponent } from '../components/products-for-shopping/products-for-shopping.component';
import { OrderComponent } from '../components/order/order.component';
import { OrderDetailsComponent } from '../components/order-details/order-details.component';
import { MyCartComponent } from '../components/my-cart/my-cart.component';
import { AdminComponent } from '../components/admin/admin.component';
import { ProductsManagementComponent } from '../components/products-management/products-management.component';
import { AdminGuardService } from '../services/admin-guard.service';


const routes: Routes = [
    { path: "register", component: RegisterComponent },
    {
        path: "home", component: HomeComponent, children: [
            { path: "login", component: LoginComponent },
            { path: "about", component: AboutComponent },
            {
                path: "general-info", component: AboutComponent, children: [
                    { path: "customer-status", component: CustomerStatusComponent, canActivate: [LoginGuardService] },
                ]
            },
        ]
    },
    {
        path: "shopping", component: ShoppingComponent, canActivate: [LoginGuardService], children: [
            { path: "products-for-shopping", component: ProductsForShoppingComponent },
            { path: "my-cart", component: MyCartComponent },
        ]
    },
    {
        path: "order", component: OrderComponent, canActivate: [LoginGuardService], children: [
            { path: "order-details", component: OrderDetailsComponent },
        ]
    },
    {
        path: "products-management", component: ProductsManagementComponent, canActivate: [AdminGuardService], children: [
            { path: "products-for-shopping", component: ProductsForShoppingComponent }
        ]
    },
    { path: "admin", component: AdminComponent },
    { path: "", pathMatch: "full", redirectTo: "home" },

    { path: "**", component: Page404Component }
];

@NgModule({
    imports: [RouterModule.forRoot(routes)],
    exports: [RouterModule]
})
export class AppRoutingModule { }
