import { Component, OnInit } from '@angular/core';
import { Customer } from '../../models/customer';
import { CustomersService } from '../../services/customers.service';
import { Title } from '../../../../node_modules/@angular/platform-browser';


@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {
   public customer = new Customer;
   public responseCustomer: Customer;
   public message: object;
   public cities: string;
   public hide = true;
  constructor(private customersService:CustomersService, private title:Title) { 
  }

  ngOnInit() {
    this.title.setTitle("Supermarket | register");
    this.cities = require("../../../assets/cities/cities.json");
  }
  public register(): void{

    this.customersService.addNewCustomer(this.customer).subscribe((responseCustomer)=>{
       if (responseCustomer.message){
        this.message = responseCustomer.message;
       }
       else{
        this.responseCustomer = responseCustomer;
       }
       
        
    },(err)=>{
        this.message = err.error.message;
    });
    
  }
}
