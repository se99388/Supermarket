import { Component, Inject } from '@angular/core';
import { Order } from '../../models/order';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material';


@Component({
    selector: 'app-dialog-after-order',
    templateUrl: './dialog-after-order.component.html',
    styleUrls: ['./dialog-after-order.component.css']
})
export class DialogAfterOrderComponent {


    constructor(public dialogRef: MatDialogRef<DialogAfterOrderComponent>, @Inject(MAT_DIALOG_DATA) public data: Order, ) { }


    confirmOrder(): void {
        // routerLink = "/home"
        this.dialogRef.close();
    }

}
