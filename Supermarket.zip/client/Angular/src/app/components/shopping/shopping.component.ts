import { Component, OnInit, Inject } from '@angular/core';
import { ProductsService } from '../../services/products.service';
import { Product } from '../../models/product';
import { ProductsCategoriesService } from '../../services/products-categories.service';
import { ProductCategory } from '../../models/productCategory';

import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { DialogPopupComponent } from '../dialog-popup/dialog-popup.component';
import { CartsService } from '../../services/carts.service';
import { Cart } from '../../models/cart';
import { NgRedux } from 'ng2-redux';
import { Store } from '../../redux/store';
import { Unsubscribe } from 'redux';
import { Item } from '../../models/item';
import { ItemsService } from '../../services/items.service';
import { CustomerStatus } from '../../models/customerStatus';
import { Title } from '../../../../node_modules/@angular/platform-browser';

export interface DialogData {
    name: string;
    _id: string;
    price: number;
    pic: string;
    categoryID: { name: string };
    quantity: number;
}
@Component({
    selector: 'app-shopping',
    templateUrl: './shopping.component.html',
    styleUrls: ['./shopping.component.css']
})
export class ShoppingComponent implements OnInit {
    public productsCategories: ProductCategory[];
    public products: Product[];
    public cart = new Cart();
    public searchValue: string;

    public unsubscribe: Unsubscribe;
    public item: Item;
    public items: Item[];
    public totalPriceCart: number = 0;
    public customerStatus: CustomerStatus


    constructor(private productsService: ProductsService, private productsCategoriesService: ProductsCategoriesService, public dialog: MatDialog, private cartsService: CartsService, private redux: NgRedux<Store>, private title: Title) { }

    ngOnInit() {
        
        this.title.setTitle("Supermarket | shopping");

        if (this.redux.getState().customer) {
            this.customerStatus = this.redux.getState().customerStatus;
            if ((this.customerStatus.newCustomer) || ( !this.customerStatus.newCustomer && this.customerStatus.closedOrder) ){

                this.cart.customerID = this.redux.getState().customer._id;
                this.cart.date = new Date();
                this.cartsService.createNewCart(this.cart);
            
            }
            else if (!this.customerStatus.newCustomer && !this.customerStatus.closedOrder){
             
                this.cartsService.addCartToStore(this.customerStatus.lastCart);
            }
           
        }

        this.unsubscribe = this.redux.subscribe(() => {
            if (this.redux.getState().items) {
                this.items = this.redux.getState().items;

                this.totalPriceCart = 0;
                for (let i = 0; i < this.items.length; i++) {
                    this.totalPriceCart += this.items[i].totalPrice;
                }
            }
        });
        this.productsCategoriesService.getProductsCategories().subscribe((responseCategories) => {
            this.productsCategories = responseCategories;
        });
    }

    public getProducts(categoryId) {
        this.productsService.getProductsByCategory(categoryId);
    }

    public search() {    
        if (!this.searchValue){
            alert("Please write your query in the search input");
        }
        else{
            this.productsService.getProductsByName(encodeURIComponent(this.searchValue));
        }
        
    }

}


