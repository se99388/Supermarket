import { Component } from '@angular/core';
import { Credentials } from '../../models/credentials';
import { Unsubscribe } from 'redux';
import { AdminService } from '../../services/admin.service';
import { Router } from '../../../../node_modules/@angular/router';

@Component({
    selector: 'app-admin',
    templateUrl: './admin.component.html',
    styleUrls: ['./admin.component.css']
})
export class AdminComponent {
    public isLoggedIn: boolean;
    public credentials = new Credentials;
    public error: string;

    constructor(private adminService: AdminService, private router: Router) { }



    public adminLogin() {

        this.adminService.getAdminDetails(this.credentials).subscribe((responseAdmin) => {
            if (responseAdmin) {
                console.log(responseAdmin);
                this.adminService.isAdminLoggedIn(responseAdmin);
                this.router.navigate(["./products-management"])
            }
            else {
                alert("wrong password or email");
            }

        });
    }
}
