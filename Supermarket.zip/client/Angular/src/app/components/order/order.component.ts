import { Component, OnInit } from '@angular/core';
import { Title } from '../../../../node_modules/@angular/platform-browser';


@Component({
    selector: 'app-order',
    templateUrl: './order.component.html',
    styleUrls: ['./order.component.css']
})
export class OrderComponent implements OnInit {


    constructor(private title: Title) { }

    ngOnInit() {
        this.title.setTitle("Supermarket | order");
    }
}


