import { Component, OnInit } from '@angular/core';
import { Customer } from '../../models/customer';
import { CustomerStatus } from '../../models/customerStatus';
import { LoginService } from '../../services/login.service';
import { Title } from '../../../../node_modules/@angular/platform-browser';

@Component({
    selector: 'app-home',
    templateUrl: './home.component.html',
    styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
    public customer: Customer;
    public isLoggedIn: boolean;
    public customerStatus: CustomerStatus;


    constructor(private title:Title,private loginService: LoginService) { }

    ngOnInit() {
        this.title.setTitle("Supermarket | home");
        if (localStorage.getItem("customerDetails")) {
            const customerDetails = JSON.parse(localStorage.getItem("customerDetails"));
            this.loginService.login(customerDetails).subscribe((customer) => {
                if (customer !== null) {
                    this.loginService.isLoggedIn(customer);
                }

            });
        }

    }
}
