import { Component, OnInit } from '@angular/core';
import { NgRedux } from 'ng2-redux';
import { Store } from '../../redux/store';
import { Customer } from '../../models/customer';
import { Unsubscribe } from 'redux';
import { Admin } from '../../models/admin';
import { LogoutService } from '../../services/logout.service';


@Component({
    selector: 'app-header',
    templateUrl: './header.component.html',
    styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {
    public customer: Customer;
    public admin: Admin;
    public unsubscribe: Unsubscribe;
    public isLoggedIn: boolean;
    public isAdminLoggedIn: boolean;
    
    constructor(private redux: NgRedux<Store>, private logoutService: LogoutService) { }

    ngOnInit(): void {

        this.unsubscribe = this.redux.subscribe(() => {
            this.customer = this.redux.getState().customer;
            this.isLoggedIn = this.redux.getState().isLoggedIn;
            this.admin = this.redux.getState().admin;
            this.isAdminLoggedIn = this.redux.getState().isAdminLoggedIn;
        });
    }

    public logout() {
        this.logoutService.doLogout();
    }
    ngOnDestroy(): void {
        this.unsubscribe();
    }
}





