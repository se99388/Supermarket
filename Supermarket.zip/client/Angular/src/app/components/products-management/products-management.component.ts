import { Component, OnInit, ViewChild, ElementRef, Input } from '@angular/core';
import { ProductCategory } from '../../models/productCategory';
import { Product } from '../../models/product';
import { ProductsService } from '../../services/products.service';
import { ProductsCategoriesService } from '../../services/products-categories.service';
import { NgRedux } from '../../../../node_modules/ng2-redux';
import { Store } from '../../redux/store';
import { ItemsService } from '../../services/items.service';
import { HttpClient } from '../../../../node_modules/@angular/common/http';
import { Router } from '../../../../node_modules/@angular/router';
import { Observable } from '../../../../node_modules/rxjs';
import { Title } from '../../../../node_modules/@angular/platform-browser';

@Component({
    selector: 'app-products-management',
    templateUrl: './products-management.component.html',
    styleUrls: ['./products-management.component.css']
})
export class ProductsManagementComponent implements OnInit {
    public productsCategories: ProductCategory[];
    public products: Product[];
    public searchValue: string;
    public newProduct: Product;
    public selectedFile: File = null;
    public category: string;
    public message: string;
    public service: any;

    constructor(private productsService: ProductsService, private productsCategoriesService: ProductsCategoriesService, private title: Title) { }




    ngOnInit() {
        this.title.setTitle("Supermarket | management");
        this.productsCategoriesService.getProductsCategories().subscribe((responseCategories) => {
            this.productsCategories = responseCategories;
        });
    }
    register(productDetails) {
        this.message = null;
        this.newProduct = null;
        this.selectedFile = null;
        this.newProduct = { ...productDetails };

    }


    public getProducts(categoryId) {
        this.category = categoryId;
        this.productsService.getProductsByCategory(categoryId);
    }
    public search() {
        if (!this.searchValue){
            alert("Please write your query in the search input");
        }
        else{
            this.productsService.getProductsByName(encodeURIComponent(this.searchValue));
        }
       
    }


    public addProduct() {
        this.newProduct = null;
        this.selectedFile = null;
        this.message = null;
        this.newProduct = new Object();
        this.newProduct.categoryID = new ProductCategory();
    }

    public onFileSelected(e) {
        this.selectedFile = e.target.files[0];

    }
    public sendingToProductService(product, url) {

        url.subscribe((res) => {
            this.message = "The product: " + res.name + " was added/updated";
            this.getProducts(product.categoryID);
            product = null;
            this.selectedFile = null;
            this.newProduct = null;
        }, err => {
            this.message = err.error.message;
            product = null;
            this.selectedFile = null;
            this.newProduct = null;
        });
    }

    public createFormData = (product) => {
        const fd = new FormData();;

        product.categoryID = product.categoryID._id;

        if (this.selectedFile) {
            fd.append('productImage', this.selectedFile);
            product.pic = "uploads/" + this.selectedFile.name;
        }

        for (let key in product) {
            fd.append(key, product[key]);
        }
        return fd;
    }
    public createNewProduct() {

        this.service = this.productsService.addProduct(this.createFormData(this.newProduct));
        this.sendingToProductService(this.newProduct, this.service);
    }



    public updateTheProduct() {
        this.service = this.productsService.updateProduct(this.createFormData(this.newProduct));
        this.sendingToProductService(this.newProduct, this.service);

    }

    public cancel() {
        this.newProduct = null;
        this.selectedFile = null;
        this.message = null;
    }
}
