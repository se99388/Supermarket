import { Component, OnInit } from '@angular/core';
import { NgRedux } from 'ng2-redux';
import { Store } from '../../redux/store';
import { Customer } from '../../models/customer';
import { Credentials } from '../../models/credentials';
import { LoginService } from '../../services/login.service';
import { CustomerStatus } from '../../models/customerStatus';
import { Title } from '@angular/platform-browser';
import { Unsubscribe } from 'redux';

@Component({
    selector: 'app-login',
    templateUrl: './login.component.html',
    styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
    public customer: Customer;
    public isLoggedIn: boolean;
    public credentials = new Credentials;
    public customerStatus: CustomerStatus;
    private unsubscribe: Unsubscribe;
    public message: string;

    constructor(private title: Title, private redux: NgRedux<Store>, private loginService: LoginService) {

           
     }

    ngOnInit(): void {    
        this.title.setTitle("Supermarket | login");
        
        this.unsubscribe = this.redux.subscribe(()=>{
            this.isLoggedIn = this.redux.getState().isLoggedIn;
            this.customerStatus = this.redux.getState().customerStatus;
        });

    }
    

    public login(): void {
        this.loginService.login(this.credentials).subscribe((customer) => {
            if (customer !== null) {
                this.loginService.isLoggedIn(customer);
                this.customer = this.redux.getState().customer;
                this.message = null;
            }
            else {
                this.message = "wrong email or password";
            }
        }, (err) => {
            alert(err.message + ". status:" + err.status + ", " + err.error.message);
        });
    }

    public ngOnDestroy(): void { 
        this.unsubscribe();
    }
}

