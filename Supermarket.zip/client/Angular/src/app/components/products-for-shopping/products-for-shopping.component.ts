import { Component, OnInit, Output, EventEmitter } from '@angular/core';
import { NgRedux } from 'ng2-redux';
import { Store } from '../../redux/store';
import { Product } from '../../models/product';
import { Unsubscribe } from 'redux';

import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { DialogPopupComponent } from '../dialog-popup/dialog-popup.component';
import { Item } from '../../models/item';
import { ItemsService } from '../../services/items.service';
import { Cart } from '../../models/cart';


export interface DialogData {
    name: string;
    _id: string;
    price: number;
    pic: string;
    categoryID: { name: string };
    quantity: number;
}

@Component({
    selector: 'app-products-for-shopping',
    templateUrl: './products-for-shopping.component.html',
    styleUrls: ['./products-for-shopping.component.css']
})


export class ProductsForShoppingComponent implements OnInit {

    @Output()
    public clickForProductDetails = new EventEmitter<string>()


    public products: Product[];
    public unsubscribe: Unsubscribe;
    public item: Item;
    public itemsInCart: Item[];
    public isLoggedIn: boolean;
    public isAdminLoggedIn: boolean;
    public cart: Cart;
    constructor(private redux: NgRedux<Store>, public dialog: MatDialog, private itemsService: ItemsService) { }

    ngOnInit() {
        this.unsubscribe = this.redux.subscribe(() => {
            this.products = this.redux.getState().products;
            this.isLoggedIn = this.redux.getState().isLoggedIn;
            this.isAdminLoggedIn = this.redux.getState().isAdminLoggedIn;
            this.cart = this.redux.getState().cart;
            this.itemsInCart = this.redux.getState().items;

        });
    }

    openDialog(currentProduct): void {
        if (this.isLoggedIn) {
            const dialogRef = this.dialog.open(DialogPopupComponent, {
                width: '500px',
                data: { _id: currentProduct._id, name: currentProduct.name, price: currentProduct.price, pic: currentProduct.pic, categoryID: currentProduct.categoryID,  quantity:1 }
            });

            dialogRef.afterClosed().subscribe(productResponse => {

                if (productResponse){
                    this.item = {
                        productID: productResponse._id,
                        quantity: productResponse.quantity,
                        totalPrice: productResponse.quantity * productResponse.price,
                        cartID: { _id: this.cart._id }
                    }
                    //for the first item in the cart
                    if (this.itemsInCart) {

                        if (this.isItemExistInCart(this.item, this.itemsInCart)) {
                            this.itemsService.updateItem(this.item);
                        }
                        else {
                            this.itemsService.addNewItemToCart(this.item);
                        }
                    }
                    else {
                        this.itemsService.addNewItemToCart(this.item);
                    }
                }
                
            });
        }
        // login by admin
        else if (this.isAdminLoggedIn) {
            this.clickForProductDetails.emit(currentProduct);
        }


    }

    public isItemExistInCart(item, allItemsInCart: Item[]) {
        for (let i = 0; i < allItemsInCart.length; i++) {
            if (item.productID === allItemsInCart[i].productID._id) {
                item.quantity += allItemsInCart[i].quantity;
                item.totalPrice += allItemsInCart[i].totalPrice;
                item._id = allItemsInCart[i]._id
                return true;
            }

        }
        return false;
    }


    ngOnDestroy(): void {
        this.unsubscribe();
    }

}
