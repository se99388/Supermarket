import { Component, OnInit } from '@angular/core';
import { OrdersService } from '../../services/orders.service';
import { OrderNum } from '../../models/order';
import { ProductsService } from '../../services/products.service';

@Component({
    selector: 'app-general-info',
    templateUrl: './general-info.component.html',
    styleUrls: ['./general-info.component.css']
})
export class GeneralInfoComponent implements OnInit {

    constructor(private ordersService: OrdersService, private productsService: ProductsService) { }
    public numOfOrders: OrderNum;
    public numOfProducts: number;
 

    ngOnInit() {
        this.ordersService.getNumOfOrders().subscribe((numOfOrders) => {
            this.numOfOrders = numOfOrders;

        });

        this.productsService.getNumOfProducts().subscribe((numOfProducts) => {
            this.numOfProducts = numOfProducts;
        });

     
    }

}
