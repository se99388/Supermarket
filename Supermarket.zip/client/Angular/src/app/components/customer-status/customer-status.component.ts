import { Component, OnInit } from '@angular/core';
import { NgRedux } from 'ng2-redux';

import { Customer } from '../../models/customer';
import { Store } from '../../redux/store';
import { CustomerStatus } from '../../models/customerStatus';
import { Unsubscribe } from 'redux';

@Component({
    selector: 'app-customer-status',
    templateUrl: './customer-status.component.html',
    styleUrls: ['./customer-status.component.css']
})
export class CustomerStatusComponent implements OnInit {
    public customerStatus = new CustomerStatus;
    public customer: Customer;
    public isLoggedIn: boolean;
    private unsubscribe: Unsubscribe;

    constructor(private redux: NgRedux<Store>) { }

    ngOnInit() {


        this.unsubscribe = this.redux.subscribe(()=>{
            this.customer = this.redux.getState().customer;
            this.isLoggedIn = this.redux.getState().isLoggedIn;
            this.customerStatus = this.redux.getState().customerStatus;
        });
        
        

    }

    public ngOnDestroy(): void { 
        this.unsubscribe();
    }
    
}
