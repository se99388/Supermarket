import { Component, OnInit } from '@angular/core';

import { Unsubscribe } from 'redux';
import { NgRedux } from 'ng2-redux';
import { Store } from '../../redux/store';
import { Customer } from '../../models/customer';
import { OrdersService } from '../../services/orders.service';
import { Order } from '../../models/order';
import { Item } from '../../models/item';
import { DatePipe } from '@angular/common';
import { MatDialog } from '@angular/material';
import { DialogAfterOrderComponent } from '../dialog-after-order/dialog-after-order.component';
import { LogoutService } from '../../services/logout.service';

@Component({
    selector: 'app-order-details',
    templateUrl: './order-details.component.html',
    styleUrls: ['./order-details.component.css']
})
export class OrderDetailsComponent implements OnInit {

    public unsubscribe: Unsubscribe;
    public customer: Customer;
    public order = new Order();

    public datePipe = new DatePipe('en-ES');
    public deliveryDates: any;
    public cities: string;

    public items: Item[];
    public totalPriceCart: number = 0;


    constructor(private ordersService: OrdersService, private redux: NgRedux<Store>, public dialog: MatDialog, private logoutService: LogoutService) {
    }

    ngOnInit() {
        this.cities = require("../../../assets/cities/cities.json");
        this.unsubscribe = this.redux.subscribe(() => {
            this.deliveryDates = {
                day0: this.datePipe.transform(new Date(), 'MM/dd/yyyy'),
                day1: this.datePipe.transform(new Date().setDate(new Date().getDate() + 1), 'MM/dd/yyyy'),
                day2: this.datePipe.transform(new Date().setDate(new Date().getDate() + 2), 'MM/dd/yyyy'),
            }
            if (this.redux.getState().customer) {
                this.customer = this.redux.getState().customer;
                this.ordersService.getLastOrderDetails(this.customer._id).subscribe((responseLastOrderDetails) => {

                    if (responseLastOrderDetails) {
                        this.order = responseLastOrderDetails;
                        this.order.city = this.order.city.toUpperCase();
                        //to make several options for delivery date.
                        //to show the default in html
                        this.order.deliveryDate = this.deliveryDates.day0;

                    }
                    //in case of new customer responseLastOrderDetails = null
                    else {
                        this.order.customerID = this.customer._id;
                    }
                });
            }


            if (this.redux.getState().items) {
                this.items = this.redux.getState().items;

                this.totalPriceCart = 0;
                for (let i = 0; i < this.items.length; i++) {
                    this.totalPriceCart += this.items[i].totalPrice;
                }
            }
        });
    }

    //function that gets the details of the current order
    public placeAnOrder() {
        this.order._id = undefined;
        this.order.totalPrice = this.totalPriceCart;
        this.order.cartID = this.items[0].cartID;
        this.order.orderDate = new Date();
        this.ordersService.addNewOrder(this.order).subscribe((responseOrder) => {
            if (responseOrder) {
                const dialogRef = this.dialog.open(DialogAfterOrderComponent, {
                    data: this.order,
                    disableClose: true
                },

                );

                dialogRef.afterClosed().subscribe(result => {
                    localStorage.removeItem("customerCart");
                    this.logoutService.doLogout();
                });
            }

        }, (err) => {
            alert(err.message + ". status:" + err.status + ", " + err.error.message);

        });

    }
    public ngOnDestroy(): void {
        this.unsubscribe();
    }

}

