import { Component, OnInit } from '@angular/core';
import { Unsubscribe } from 'redux';
import { Item } from '../../models/item';
import { NgRedux } from 'ng2-redux';
import { Store } from '../../redux/store';
import { ItemsService } from '../../services/items.service';
import { Cart } from '../../models/cart';

@Component({
    selector: 'app-item',
    templateUrl: './item.component.html',
    styleUrls: ['./item.component.css']
})
export class ItemComponent implements OnInit {


    public unsubscribe: Unsubscribe;
    public items: Item[];
    public cart: Cart;
    public totalPriceCart: number = 0;
    constructor(private redux: NgRedux<Store>, private itemsService: ItemsService) { }

    ngOnInit() {

        if (this.redux.getState().cart){
        this.itemsService.addItemsToStoreFromServer(this.redux.getState().cart._id)
    }
    else{
        if(localStorage.getItem("customerCart")){

            this.cart = JSON.parse(localStorage.getItem("customerCart"));
            this.itemsService.addItemsToStoreFromServer (this.cart._id);
        }
    }

        this.unsubscribe = this.redux.subscribe(() => {
            if (this.redux.getState().items) {
                this.items = this.redux.getState().items;

                this.totalPriceCart = 0;
                for (let i = 0; i < this.items.length; i++) {
                    this.totalPriceCart += this.items[i].totalPrice;
                }
            }
        });
    }

    public ngOnDestroy(): void { 
        this.unsubscribe();
    }

}
