import { Component, OnInit } from '@angular/core';
import { Unsubscribe } from 'redux';
import { NgRedux } from 'ng2-redux';
import { Store } from '../../redux/store';
import { Item } from '../../models/item';
import { ItemsService } from '../../services/items.service';
import { Cart } from '../../models/cart';

@Component({
    selector: 'app-my-cart',
    templateUrl: './my-cart.component.html',
    styleUrls: ['./my-cart.component.css']
})
export class MyCartComponent implements OnInit {
    public unsubscribe: Unsubscribe;
    public items: Item[];
    public cart: Cart

    constructor(private redux: NgRedux<Store>, private itemsService: ItemsService) { }

    ngOnInit() {
        if (this.redux.getState().cart){
            this.itemsService.addItemsToStoreFromServer(this.redux.getState().cart._id)
        }
        else{
            if(localStorage.getItem("customerCart")){
                this.cart = JSON.parse(localStorage.getItem("customerCart"));
                this.itemsService.addItemsToStoreFromServer (this.cart._id);
            }
        }
        
        this.unsubscribe = this.redux.subscribe(() => {
         
            if (this.redux.getState().items) {
                this.items = this.redux.getState().items;
            }
        });
    }
        public clearCart(cartId){
            this.itemsService.deleteAllItemsFromCart(cartId);
        }

        public removeItem(item: Item){
            this.itemsService.deleteItemFromCart(item);
        }
}
