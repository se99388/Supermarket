export class Admin {

    constructor(public _id?: string,
        public firstName?: string,
        public lastName?: string,
        public email?: string,
        public password?: string,
    ) {

    }

}
