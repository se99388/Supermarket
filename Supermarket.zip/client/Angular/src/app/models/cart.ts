export class Cart {

    constructor(public _id?: string,
        public customerID?: string,
        public date?: Date
    ) {

    }

}
