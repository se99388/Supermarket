export class Credentials {
    public constructor(public password?: string, public email?: string){
    }
}