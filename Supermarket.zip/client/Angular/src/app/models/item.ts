import { Product } from './product';
import { Cart } from './cart';

export class Item {

    constructor(public _id?: string,
        public productID?: Product,
        public quantity?: number,
        public totalPrice?: number,
        public cartID?: Cart
    ) {

    }

}
