export class Customer{

    constructor( public _id?: string,
        public firstName?: string,
        public lastName?: string,
        public email?: string,
        public password?: string,
        public idNum?: string,
        public city?: string,
        public street?: string
    ){

    }
   
}