import { Cart } from './cart';

export class CustomerStatus{
    constructor(public newCustomer?: boolean,
        public message?: string,
        public lastCart?: Cart,
        public closedOrder?: boolean,
        public itemsSumInOpenCart?: number){
    }
}