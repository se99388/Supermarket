import { Cart } from './cart';


export class OrderNum {
    constructor(public numOfOrders?: number) {
    }
}

export class Order {
    constructor(public _id?: string,
        public customerID?: string,
        public cartID?: Cart,
        public totalPrice?: number,
        public city?: string,
        public street?: string,
        public homeNum?: number,
        public deliveryDate?: Date,
        public creditCard?: string,
        public orderDate?: Date
    ) {
    }
}
