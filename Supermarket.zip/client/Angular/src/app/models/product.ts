import { ProductCategory } from './productCategory';

export class Product {

    constructor(public _id?: string,
        public name?: string,
        public price?: number,
        public pic?: string,
        public categoryID?: any,
    ) {

    }

}

export class ProductWithoutCategoryObject {

    constructor(public _id?: string,
        public name?: string,
        public price?: number,
        public pic?: string,
        public categoryID?: any,
    ) {

    }

}
