import { Injectable } from '@angular/core';
import { NgRedux } from '../../../node_modules/ng2-redux';
import { Router } from '../../../node_modules/@angular/router';
import { Store } from '../redux/store';
import { ActionType } from '../redux/action';

@Injectable({
  providedIn: 'root'
})
export class LogoutService {

  constructor(private redux:NgRedux<Store>, private router: Router) {
    
   }

  public doLogout(){
    sessionStorage.removeItem("isLoggedIn");
    localStorage.removeItem("isLoggedIn");
    localStorage.removeItem("customerDetails");

    sessionStorage.removeItem("isAdminLoggedIn");
    localStorage.removeItem("isAdminLoggedIn");
    localStorage.removeItem("adminDetails");
    localStorage.removeItem("customerCart");

    const action = { type: ActionType.logout }
    this.redux.dispatch(action);
    const actionItem = { type: ActionType.getItems, payload: undefined }
    this.redux.dispatch(actionItem);
    const actionCart = { type: ActionType.getOneCart, payload: undefined }
    this.redux.dispatch(actionCart);
    this.router.navigate(["/home"]);
  }
}
