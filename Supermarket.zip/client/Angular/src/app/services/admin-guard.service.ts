import { Injectable } from '@angular/core';
import { NgRedux } from '../../../node_modules/ng2-redux';
import { Store } from '../redux/store';
import { CanActivate, Router, ActivatedRouteSnapshot, RouterStateSnapshot } from '../../../node_modules/@angular/router';


@Injectable({
  providedIn: 'root'
})


export class AdminGuardService implements CanActivate{

    constructor(private redux: NgRedux<Store>, private router: Router) { }

    public canActivate(): boolean {
        if (this.redux.getState().isAdminLoggedIn) {
            return true;
        }
        this.router.navigate(["/home"]);
        return false;
    }
}
