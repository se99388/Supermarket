import { Injectable } from '@angular/core';
import { NgRedux } from 'ng2-redux';
import { HttpClient } from '@angular/common/http';
import { Store } from '../redux/store';
import { Credentials } from '../models/credentials';
import { ActionType } from '../redux/action';
import { Customer } from '../models/customer';
import { Observable } from 'rxjs';
import { CustomerStatus } from '../models/customerStatus';


@Injectable({
    providedIn: 'root'
})
export class LoginService {
  
    public customerStatus: CustomerStatus;
    public constructor(private redux: NgRedux<Store>, private httpClient: HttpClient) { }


    public login(credentials: Credentials): Observable<Customer> {

        return this.httpClient.get<Customer>("http://localhost:3000/api/supermarket/customer/" + credentials.password + "/" + credentials.email )
    }

    public isLoggedIn(customer){
        const customerDetails: object = {
            password: customer.password,
            email: customer.email
        }
        sessionStorage.setItem("isLoggedIn", "true");
        localStorage.setItem("isLoggedIn", "true");
        localStorage.setItem("customerDetails", JSON.stringify(customerDetails));
        this.customerLastOrderStatus(customer._id).subscribe((customerStatus)=>{

            const actionLogin = { type: ActionType.login, payload: customerStatus};
            this.redux.dispatch(actionLogin);
        });

        const actionCustomer = { type: ActionType.getOneCustomer, payload: customer};
        this.redux.dispatch(actionCustomer);

    }

    public customerLastOrderStatus(customerId): Observable<CustomerStatus> {

        return this.httpClient.get<CustomerStatus>("http://localhost:3000/api/supermarket/carts/" + customerId)
    }

}
