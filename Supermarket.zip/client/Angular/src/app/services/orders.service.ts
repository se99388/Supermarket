import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { OrderNum, Order } from '../models/order';
import { HttpClient } from '@angular/common/http';

@Injectable({
    providedIn: 'root'
})
export class OrdersService {

    constructor(private httpClient: HttpClient) { }

    public getNumOfOrders(): Observable<OrderNum> {
        return this.httpClient.get<OrderNum>("http://localhost:3000/api/supermarket/orders/count");
    }

    public getLastOrderDetails(customerId: string): Observable<Order> {
        return this.httpClient.get<Order>("http://localhost:3000/api/supermarket/orders/last-order-details/" + customerId);
    }

    public addNewOrder(order:Order): Observable<Order>{
        return this.httpClient.post<Order>("http://localhost:3000/api/supermarket/orders", order);
    }
    
}
