import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Item } from '../models/item';
import { ActionType } from '../redux/action';
import { NgRedux } from 'ng2-redux';
import { Store } from '../redux/store';

@Injectable({
    providedIn: 'root'
})
export class ItemsService {

    constructor(private httpClient: HttpClient, private redux: NgRedux<Store>) { }



    public addNewItemToCart(item: Item) {
        this.httpClient.post<Item>("http://localhost:3000/api/supermarket/items", item).subscribe(() => {
            this.addItemsToStoreFromServer(item.cartID._id);
        })
    }

    public updateItem(item: Item) {
    
        this.httpClient.put<Item>("http://localhost:3000/api/supermarket/item-to-update/"+ item._id, item).subscribe((response) => {
            this.addItemsToStoreFromServer(response.cartID._id);
        },(err)=>{
          alert(err.message + ". status:" + err.status + ", " + err.error.message);
        })
    }


 
    public deleteItemFromCart(item: Item) {
        this.httpClient.delete<Item>("http://localhost:3000/api/supermarket/items/delete/" + item._id).subscribe(() => {
        
            this.addItemsToStoreFromServer(item.cartID._id);
        })
    }

    public deleteAllItemsFromCart(cartID: string) {
        this.httpClient.delete<string>("http://localhost:3000/api/supermarket/items/delete-all-items/" + cartID).subscribe(() => {
        
            this.addItemsToStoreFromServer(cartID);
        })
    }

    public addItemsToStoreFromServer(cartID: string) {
    
        this.httpClient.get<Item[]>("http://localhost:3000/api/supermarket/items/" + cartID).subscribe((responseItems) => {
      
        const action = { type: ActionType.getItems, payload: responseItems }
            this.redux.dispatch(action);
        });
    }
    public getAllItemsByCart(cartID: string): Observable<Item[]> {
        return this.httpClient.get<Item[]>("http://localhost:3000/api/supermarket/items/" + cartID)
    }

}
