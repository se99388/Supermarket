import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import { Product } from '../models/product';
import { ActionType } from '../redux/action';
import { NgRedux } from 'ng2-redux';
import { Store } from '../redux/store';

@Injectable({
    providedIn: 'root'
})
export class ProductsService {

    constructor(private httpClient: HttpClient, private redux: NgRedux<Store>) { }

    public getNumOfProducts(): Observable<number> {
        return this.httpClient.get<number>("http://localhost:3000/api/supermarket/products/count")
    }

    public addProduct(product: FormData):Observable<Product>{
        return this.httpClient.post<Product>("http://localhost:3000/api/supermarket/products", product);
    }

    public updateProduct(product: FormData):Observable<Product>{
        return this.httpClient.put<Product>("http://localhost:3000/api/supermarket/products", product);
    }
   


    public getProductsByCategory(categoryId) :void {
        this.httpClient.get<Product[]>("http://localhost:3000/api/supermarket/products/category/" + categoryId).subscribe((responseProducts)=>{

        const action = { type: ActionType.getProducts, payload: responseProducts};
        this.redux.dispatch(action);
        });

    }


    public getProductsByName(productName) :void {
        this.httpClient.get<Product[]>("http://localhost:3000/api/supermarket/products/name/" + productName).subscribe((responseProducts)=>{
          
            if(!responseProducts.length){
                alert("No product found");
            }
            else{
                const action = { type: ActionType.getProducts, payload: responseProducts};
                this.redux.dispatch(action);
            }
        
        });
    }
}


