import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { NgRedux } from 'ng2-redux';
import { Store } from '../redux/store';
import { Customer } from '../models/customer';
import { ActionType } from '../redux/action';
import { Observable } from 'rxjs';


@Injectable({
    providedIn: 'root'
})
export class CustomersService {

    public constructor(private httpClient: HttpClient, private redux: NgRedux<Store>) { }

    public getAllCustomers(): void {
        this.httpClient.get<Customer[]>("http://localhost:3000/api/supermarket/customers").subscribe((customers) => {
            const action = { type: ActionType.getAllCustomers, payload: customers };
            this.redux.dispatch(action);
        });
    }

    public customerLastOrderStatus(customerId): Observable<object> {

        return this.httpClient.get<object>("http://localhost:3000/api/supermarket/carts/" + customerId)
    }

    //any because it can return a message and not a customer object
    public addNewCustomer(customer): Observable<any>{
        return this.httpClient.post<any>("http://localhost:3000/api/supermarket/customers", customer)
    }
}
