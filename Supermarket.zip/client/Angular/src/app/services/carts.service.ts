import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { NgRedux } from 'ng2-redux';
import { Store } from '../redux/store';
import { Cart } from '../models/cart';
import { ActionType } from '../redux/action';

@Injectable({
  providedIn: 'root'
})
export class CartsService {

    public constructor(private httpClient: HttpClient, private redux: NgRedux<Store>) { }

    public createNewCart(newCart): void {
        
        this.httpClient.post<Cart>("http://localhost:3000/api/supermarket/new-cart", newCart).subscribe((cartResponse) => {
           
            localStorage.setItem("customerCart", JSON.stringify(cartResponse));
            const action = { type: ActionType.getOneCart, payload: cartResponse };
            this.redux.dispatch(action);
        });
    }

    public addCartToStore(cart:Cart): void {

        localStorage.setItem("customerCart", JSON.stringify(cart));
            const action = { type: ActionType.getOneCart, payload: cart };
            this.redux.dispatch(action);
    }
}
