import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Credentials } from '../models/credentials';
import { Observable } from 'rxjs';
import { Admin } from '../models/admin';
import { NgRedux } from '../../../node_modules/ng2-redux';
import { Store } from '../redux/store';
import { ActionType } from '../redux/action';

@Injectable({
    providedIn: 'root'
})
export class AdminService {

    constructor(private httpClient: HttpClient, private redux: NgRedux<Store>) { }

    public getAdminDetails(credentials: Credentials): Observable<Admin> {
        return this.httpClient.get("http://localhost:3000/api/supermarket/admin/" + credentials.email + "/" + credentials.password);
    }

    public isAdminLoggedIn(admin) {
        const adminDetails: object = {
            password: admin.password,
            email: admin.email
        }
        sessionStorage.setItem("isAdminLoggedIn", "true");
        localStorage.setItem("isAdminLoggedIn", "true");
        localStorage.setItem("adminDetails", JSON.stringify(adminDetails));
        const actionAdminLogin = { type: ActionType.adminLogin };
        this.redux.dispatch(actionAdminLogin);
        const actionAdminDetails = { type: ActionType.getOneAdmin, payload: admin };
        this.redux.dispatch(actionAdminDetails);

    }
}
