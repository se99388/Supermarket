import { Customer } from '../models/customer';
import { Cart } from '../models/cart';
import { Item } from '../models/item';
import { Product } from '../models/product';
import { Admin } from '../models/admin';
import { CustomerStatus } from '../models/customerStatus';

export class Store{
    public isLoggedIn: boolean;
    public isAdminLoggedIn: boolean;

    public admin: Admin;
    public customers: Customer[];
    public customer: Customer;
    public cart: Cart
    public items: Item[];
    public item: Item;
    public products: Product[];
    public customerStatus: CustomerStatus;

    public constructor(){
        if (sessionStorage.getItem("isLoggedIn")){
            this.isLoggedIn = true;
        }
        if (localStorage.getItem("isLoggedIn")){
            this.isLoggedIn = true;
        }

        if (sessionStorage.getItem("isAdminLoggedIn")){
            this.isAdminLoggedIn = true;
        }
        if (localStorage.getItem("isAdminLoggedIn")){
            this.isAdminLoggedIn = true;
        }
    }
}