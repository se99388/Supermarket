export enum ActionType {
    getAllCustomers,
    getOneCustomer,
    getOneAdmin,
    login,
    logout,
    getOneCart,
    getProducts,
    getItems,
    adminLogin,
}

export interface Action{
    type: ActionType;
    payload?: any; 
}