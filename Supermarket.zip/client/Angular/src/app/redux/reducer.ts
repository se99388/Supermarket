import { Store } from './store';
import { Action, ActionType } from './action';


export class Reducer{
    public static reduce(oldStore: Store, action: Action):Store{
        const newStore = {...oldStore};
        switch (action.type){
            case ActionType.login:
            newStore.isLoggedIn = true;
            newStore.customerStatus = action.payload;
            break;

            case ActionType.logout:
            newStore.isLoggedIn = false;
            newStore.isAdminLoggedIn = false;
            break;

            case ActionType.adminLogin:
            newStore.isAdminLoggedIn = true;
            break;

            case ActionType.getOneAdmin:
            newStore.admin = action.payload;
            break;

            case ActionType.getOneCustomer:
            newStore.customer = action.payload;
            break;

            case ActionType.getAllCustomers:
            newStore.customers = action.payload;
            break;

            case ActionType.getOneCart:
            newStore.cart = action.payload;
            break;

            case ActionType.getProducts:
            newStore.products = action.payload;
            break;

            case ActionType.getItems:
            newStore.items = action.payload;
            break;


        }
        return newStore;
    }
}