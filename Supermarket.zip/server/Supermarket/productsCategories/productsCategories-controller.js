const express = require("express");
const productsCategoriesLogic = require("./productsCategories-logic");

const router = express.Router();


//Products
router.get("/productsCategories", async (request, response)=>{
    try{
        const productsCategories = await productsCategoriesLogic.getAllProductsCategories();
        response.json(productsCategories);
    }
    catch(err){
        res.status(500).json(err);
    } 
});




module.exports = router;