const models = require("../models/models");


async function getAllProductsCategories(){
    return new Promise((resolve, reject)=>{
        models.ProductCategory.find({},(err,productCategory)=>{
            if (err){
                reject(err);
            }
            else{
                resolve(productCategory);
            }
        });
    });
}



module.exports = {
    getAllProductsCategories
}