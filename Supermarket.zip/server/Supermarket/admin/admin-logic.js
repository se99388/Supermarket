const models = require("../models/models");


async function getAdmin(email, password) {
    return new Promise((resolve, reject) => {
        models.Admin.findOne({password: password, email: email}).exec((err, admin) => {
            if (err) {
                reject(err);
            }
            else {
                resolve(admin);
            }
        });
    });
}


// async function getAllItemsByCartID(cartId) {
//     return new Promise((resolve, reject) => {
//         models.Item.find({ cartID: cartId }).populate({ path: "productID", populate: { path: "categoryID" } }).populate("cartID").exec((err, items) => {
//             if (err) {
//                 reject(err);
//             }
//             else {
//                 resolve(items)
//             }
//         });
//     });
// }
// async function addOneItem(item) {
//     return new Promise((resolve, reject) => {
//         const newItem = new models.Item(item);
//         console.log(newItem)
//         newItem.save((err, responseItem) => {
//             if (err) {
//                 reject(err);
//             }
//             else {
//                 resolve(responseItem)
//             }
//         });
//     });
// }

// async function updateOneItem(item) {
//     return new Promise((resolve, reject) => {

//         models.Item.updateOne({ _id: item._id }, item, (err, info) => {
//             if (err) {
//                 reject(err);
//             }
//             else {

//             }
//         });
//     });
// }

// async function deleteOneItemByCart(itemId) {
//     return new Promise((resolve, reject) => {
//         models.Item.deleteOne({ _id: itemId }, (err, info) => {
//             if (err) {
//                 reject(err);
//             }
//             else {
//                 resolve(info);
//             }
//         });
//     });
// }

// async function deleteAllItemByCart(cartId) {
//     return new Promise((resolve, reject) => {
//         models.Item.deleteMany({ cartID: cartId }, (err, info) => {
//             if (err) {
//                 console.log("bad")
//                 reject(err);
//             }
//             else {
//                 console.log("good", info)
//                 resolve(info);
//             }
//         });
//     });
// }






module.exports = {
    getAdmin
}