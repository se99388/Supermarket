const express = require("express");
const adminLogic = require("./admin-logic");

const router = express.Router();


router.get("/admin/:email/:password", async (request, response) => {
    try {
        const email = request.params.email;
        const password = request.params.password;
        const admin = await adminLogic.getAdmin(email, password);
        response.json(admin);
    }
    catch (err) {
        response.status(500).json(err);
    }
});



module.exports = router;