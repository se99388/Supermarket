const express = require("express");
const productsLogic = require("./products-logic");
const multer = require("multer");
const models = require("../models/models")

const storageImage = multer.diskStorage({
    destination: (request, file, cb) => {
        cb(null, './uploads/');
    },
    filename: (request, file, cb) => {
        cb(null, file.originalname);
    }
});

const fileFilter = (request, file, cb) => {
    if (file.mimetype === 'image/jpeg' || file.mimetype === 'image/png') {
        cb(null, true);
    } else {
        cb(new Error('not image of type jpeg or png'), true);
    }
}

const upload = multer({ storage: storageImage, fileFilter:fileFilter });

const router = express.Router();



router.get("/products", async (request, response) => {
    try {
        const products = await productsLogic.getAllProducts();
        response.json(products);
    }
    catch (err) {
        response.status(500).json(err);
    }
});

router.get("/products/count", async (request, response) => {
    try {
        const productsNum = await productsLogic.getNumOfProducts();
        response.json(productsNum);
    }
    catch (err) {
        response.status(500).json(err);
    }
});


router.get("/products/name/:name", async (request, response) => {
    try {
        console.log(request.params.name)
        const products = await productsLogic.getProductsByName(request.params.name);
        response.json(products);
    }
    catch (err) {
        response.status(500).json(err);
    }
});

router.get("/products/category/:category", async (request, response) => {
    try {
        const allProducts = await productsLogic.getProductsByCategory(request.params.category);
        response.json(allProducts);
    }
    catch (err) {
        response.status(500).json(err);
    }
});


router.post("/products", upload.single('productImage'), async (request, response) => {
    try {
        const product = new models.Product(request.body);
        
        if (request.file != undefined){
            product.pic = request.file.path;
        }
     
        const newProduct = await productsLogic.addOneProduct(product);
        response.status(201).json(newProduct);
    }
    catch (err) {
        response.status(500).json(err);
        console.log(err)
    }
});

router.put("/products", upload.single('productImage'), async (request, response) => {
    try {
        console.log(request.file);

        const product = new models.Product(request.body);
        console.log(product);
       if (request.file != undefined){
            product.pic = request.file.path;
        }
        
        const info = await productsLogic.updateOneProduct(product);
        if (info.n) {
            response.json(product);
        }
        else {
            response.status(404).json({ message: "ID: " + product._id + " Not found" })
        }
        
    }
    catch (err) {
        response.status(500).json(err);
    }
});



module.exports = router;