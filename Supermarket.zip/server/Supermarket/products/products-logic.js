const models = require("../models/models");


async function getAllProducts(){
    return new Promise((resolve, reject)=>{
        models.Product.find({}).populate("categoryID").exec((err,products)=>{
            if (err){
                reject(err);
            }
            else{
                resolve(products)
            }
        });
    });
}

async function getProductsByName(productName){
    return new Promise((resolve, reject)=>{
        models.Product.find({name: new RegExp('.*' + productName + '.*', "i")}).populate("categoryID").exec((err,products)=>{
            if (err){
                reject(err);
            }
            else{
                resolve(products)
            }
        });
    });
}

async function getProductsByCategory(category){
    return new Promise((resolve, reject)=>{
        models.Product.find({categoryID:category}).populate("categoryID").exec((err,products)=>{
            if (err){
                reject(err);
            }
            else{
                resolve(products)
            }
        });
    });
}

async function getNumOfProducts(){
    return new Promise((resolve, reject)=>{
        models.Product.countDocuments({}).exec((err,productsCount)=>{
            if (err){
                reject(err);
            }
            else{
                resolve(productsCount);
            }
        });
    });
}

async function updateOneProduct(product) {
    return new Promise((resolve, reject) => {

        models.Product.updateOne({ _id: product._id }, product, (err, info) => {
            if (err) {
                reject(err);
            }
            else {
                resolve(info);
            }
        });
    });
}

async function addOneProduct(product) {
    return new Promise((resolve, reject) => {
     
        console.log(product);
        product.save((err, responseProduct) => {
            if (err) {
                reject(err);
            }
            else {
                resolve(responseProduct)
            }
        });
    });
}


module.exports = {
    getAllProducts,
    getNumOfProducts,
    getProductsByCategory,
    getProductsByName,
    updateOneProduct,
    addOneProduct
}