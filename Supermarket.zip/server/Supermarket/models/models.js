const dal = require("../dal");
const mongoose = dal.mongoose;

const productCategorySchema = new mongoose.Schema({
    name: String
});


const productSchema = new mongoose.Schema({
    name :  {type: String, required:true},
    price :  {type: Number, required:true},
    pic :  {type: String, required:true},
    categoryID : {type: mongoose.Schema.Types.ObjectId, ref: "ProductCategory" , required:true}
});

const customerSchema = new mongoose.Schema({
    firstName: {type:String, required: true},
    lastName: {type:String, required: true},
    email: {type:String, required: true},
    password: {type:String, required: true},
    city: {type:String, required: true},
    street: {type:String, required: true}
});

const orderSchema = new mongoose.Schema({
    customerID: {type: mongoose.Schema.Types.ObjectId, ref: "Customer", required:true},
    cartID: {type: mongoose.Schema.Types.ObjectId, ref: "ShoppingCart"},
    totalPrice: {type: Number, required:true},
    city:  {type: String, required:true},
    street:  {type: String, required:true},
    homeNum: {type: Number, required:true},
    deliveryDate:  {type: String, required:true},
    creditCard: {type: String, required:true},
    orderDate:  {type: Date, required:true}
});

const shoppingCartSchema = new mongoose.Schema({
    customerID: {type: mongoose.Schema.Types.ObjectId, ref: "Customer"},
    date: Date
});

const itemSchema = new mongoose.Schema({
    productID: {type: mongoose.Schema.Types.ObjectId, ref: "Product"},
    quantity: Number,
    totalPrice: Number,
    cartID: {type: mongoose.Schema.Types.ObjectId, ref: "ShoppingCart"}
});

const adminSchema = new mongoose.Schema({
    firstName: String,
    lastName: String,
    email: String,
    password: String,
});

const Admin = mongoose.model("Admin", adminSchema, "administrators")
const ProductCategory = mongoose.model("ProductCategory",productCategorySchema,"productsCategories");
const Product = mongoose.model("Product", productSchema, "products");
const Customer = mongoose.model("Customer", customerSchema, "customers");
const Order = mongoose.model("Order", orderSchema, "orders");
const ShoppingCart = mongoose.model("ShoppingCart", shoppingCartSchema, "shoppingCarts");
const Item = mongoose.model("Item", itemSchema, "items");


module.exports = {
    Admin,
    ProductCategory,
    Product,
    Customer,
    Order,
    ShoppingCart,
    Item
}
