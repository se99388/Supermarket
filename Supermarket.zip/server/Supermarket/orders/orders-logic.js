const models = require("../models/models");


async function getNumOfOrders(){
    return new Promise((resolve, reject)=>{
        models.Order.countDocuments({}).exec((err,orders)=>{
            if (err){
                reject(err);
            }
            else{
                resolve(orders);

            }
        });
    });
}

async function getLastOrderByCustomerIDAndCartID(customerId, cartId){

    return new Promise((resolve, reject)=>{
        models.Order.findOne().and({customerID: customerId }).and({cartID: cartId}).sort({date:-1}).limit(1).exec((err,order)=>{
            if (err){
                reject(err);
            }
            else{
                resolve(order);

            }
        });
    });
}


async function getLastOrderByCustomerID(customerId){
    console.log(customerId);
  return new Promise((resolve, reject)=>{
      models.Order.findOne({customerID: customerId }).sort({orderDate:-1}).limit(1).exec((err,order)=>{
          if (err){
              reject(err);
          }
          else{
              resolve(order);
          }
      });
  });
}

async function addOneOrder(order) {
    return new Promise((resolve, reject) => {
        const newOrder = new models.Order(order);
        newOrder.save((err, responseOrder) => {
            if (err) {
                reject(err);
            }
            else {
                resolve(responseOrder);
            }
        });
    });
}


module.exports = {
    getNumOfOrders,
    getLastOrderByCustomerIDAndCartID,
    getLastOrderByCustomerID,
    addOneOrder
}