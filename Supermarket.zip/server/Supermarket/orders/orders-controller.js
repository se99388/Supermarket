const express = require("express");
const ordersLogic = require("./orders-logic");

const router = express.Router();


router.get("/orders/count", async (request, response) => {
    try{
        const ordersNum = await ordersLogic.getNumOfOrders();
        response.json(ordersNum);
    }
    catch(err){
        response.status(500).json(err);
    } 
});

router.post("/carts", async (request, response) => {
    try {
        const cart = request.body;
        const newCart = await cartsLogic.addOneCart(cart);
        response.status(201).json(newCart);
    }
    catch (err) {
        response.status(500).json(err);
    }
});

router.get("/orders/last-order-details/:customerId", async (request, response) => {
    try {
        const customerId = request.params.customerId;
        //get the last shopping cart by customer id
        const lastOrder = await ordersLogic.getLastOrderByCustomerID(customerId);
        response.json(lastOrder);
    }
    catch (err) {
        response.status(500).json(err);
    }
});

router.post("/orders", async (request, response) => {
    try {
        const order = request.body;
        const newOrder = await ordersLogic.addOneOrder(order);
        response.status(201).json(newOrder);
    }
    catch (err) {
        response.status(500).json(err);
    }
});



module.exports = router;