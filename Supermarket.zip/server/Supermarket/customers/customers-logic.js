const models = require("../models/models");


async function getAllCustomers() {
    return new Promise((resolve, reject) => {
        models.Customer.find({}).exec((err, customers) => {
            if (err) {
                reject(err);
            }
            else {
                resolve(customers)
            }
        });
    });
}

async function getOneCustomer(password, email) {
    return new Promise((resolve, reject) => {
        models.Customer.findOne({ password: password, email: email }).exec((err, customer) => {
            if (err) {
                reject(err);
            }
            else {
                resolve(customer);

            }
        });
    });
}

async function CheckIfCustomerExist(customer) {
    return new Promise((resolve, reject) => {
        models.Customer.findOne({ email: customer.email }).exec((err, customerExist) => {
            if (err) {
                reject(err);
            }
            else {
                resolve(customerExist);
            }
        });
    });
}

async function AddOneCustomer(customer) {
    return new Promise((resolve, reject) => {
        const newCustomer = new models.Customer(customer);
        newCustomer.save((err, customerResponse) => {
            if (err) {
                reject(err);
            }
            else {
                resolve(customerResponse);
            }
        });
    });
}


module.exports = {
    getAllCustomers,
    getOneCustomer,
    AddOneCustomer,
    CheckIfCustomerExist
}