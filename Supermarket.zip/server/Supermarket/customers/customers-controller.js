const express = require("express");
const customersLogic = require("./customers-logic");

const router = express.Router();

//Customers 
router.get("/customers", async (request, response) => {
    try {
        const customers = await customersLogic.getAllCustomers();
        response.json(customers);
    }
    catch (err) {
        response.status(500).json(err);
    }
});

router.get("/customer/:password/:email", async (request, response) => {
    try {
        const password = request.params.password;
        const email = request.params.email;
        const customer = await customersLogic.getOneCustomer(password, email);

        if (!customer == "") {
            response.json(customer);
        }
        else {
            const message = { message: "customer Not Found" };
            //I chose status 204 (no content) and not 404 to avoid errors in my console
            response.status(204).json(message);
        }
    }
    catch (err) {
        response.status(500).json(err);
    }
});

router.post("/customers", async (request, response) => {
    try {
        const customerAlreadyExist = await customersLogic.CheckIfCustomerExist(request.body);
        if (customerAlreadyExist){
            const message = { message: "You already registered with the following email: " +  customerAlreadyExist.email};
            response.json(message);
        }
        else{
            const addedCustomers = await customersLogic.AddOneCustomer(request.body);
            response.status(201).json(addedCustomers);
        }
        
    }
    catch (err) {
        response.status(500).json(err);
    }
});

module.exports = router;