const express = require("express");
const itemsLogic = require("./items-logic");

const router = express.Router();




//items
router.get("/items", async (request, response) => {
    try {
        const items = await itemsLogic.getAllItems();
        response.json(items);
    }
    catch (err) {
        response.status(500).json(err);
    }
});

router.get("/items/:cartID", async (request, response) => {
    try {
        const items = await itemsLogic.getAllItemsByCartID(request.params.cartID);
        response.json(items);
    }
    catch (err) {
        response.status(500).json(err);
    }
});

router.post("/items", async (request, response) => {
    try {
        const item = request.body;
        const newItem = await itemsLogic.addOneItem(item);
        response.status(201).json(newItem);
    }
    catch (err) {
        response.status(500).json(err);
    }
});

router.put("/item-to-update/:_id", async (request, response) => {
    try {
        const item = request.body;
        item._id = request.params._id;
        const info = await itemsLogic.updateOneItem(item);
        if (info.n) {
            response.json(item);
        }
        else {
            response.status(404).json({ message: "ID: " + item._id + " Not found" })
        }
    }
    catch (err) {
        response.status(500).json(err)
    }
});

router.delete("/items/delete/:_id", async (request, response) => {
    try {
        const info = await itemsLogic.deleteOneItemByCart(request.params._id);
        if (info.deletedCount) {
            response.status(204).send();
        }
        else {
           
            response.status(404).json("wrong ID");
        }
    }
    catch (err) {
        response.status(500).json(err);
    }
});

router.delete("/items/delete-all-items/:cartID", async (request, response) => {
    try {
        const info = await itemsLogic.deleteAllItemByCart(request.params.cartID);
        if (info.deletedCount) {
            response.status(204).send();
        }
        else {
           
            response.status(404).json("wrong cartID");
        }
    }
    catch (err) {
        response.status(500).json(err);
    }
});



module.exports = router;