const models = require("../models/models");

//Items:
async function getAllItems() {
    return new Promise((resolve, reject) => {
        models.Item.find({}).populate(["productID", "cartID"]).exec((err, items) => {
            if (err) {
                reject(err);
            }
            else {
                resolve(items)
            }
        });
    });
}


async function getAllItemsByCartID(cartId) {
    return new Promise((resolve, reject) => {
        models.Item.find({ cartID: cartId }).populate({ path: "productID", populate: { path: "categoryID" } }).populate("cartID").exec((err, items) => {
            if (err) {
                reject(err);
            }
            else {
                resolve(items)
            }
        });
    });
}
async function addOneItem(item) {
    return new Promise((resolve, reject) => {
        const newItem = new models.Item(item);
        newItem.save((err, responseItem) => {
            if (err) {
                reject(err);
            }
            else {
                resolve(responseItem)
            }
        });
    });
}


async function updateOneItem(item) {
    return new Promise((resolve, reject) => {

        models.Item.updateOne({ _id: item._id }, item, (err, info) => {
            if (err) {
                reject(err);
            }
            else {
                resolve(info);
            }
        });
    });
}

async function deleteOneItemByCart(itemId) {
    return new Promise((resolve, reject) => {
        models.Item.deleteOne({ _id: itemId }, (err, info) => {
            if (err) {
                reject(err);
            }
            else {
                resolve(info);
            }
        });
    });
}

async function deleteAllItemByCart(cartId) {
    return new Promise((resolve, reject) => {
        models.Item.deleteMany({ cartID: cartId }, (err, info) => {
            if (err) {
                reject(err);
            }
            else {
                resolve(info);
            }
        });
    });
}






module.exports = {
    getAllItems,
    addOneItem,
    updateOneItem,
    getAllItemsByCartID,
    deleteOneItemByCart,
    deleteAllItemByCart
}