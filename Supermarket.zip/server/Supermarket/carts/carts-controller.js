const express = require("express");
const cartsLogic = require("./carts-logic");
const ordersLogic = require("../orders/orders-logic");
const itemLogic = require("../items/items-logic");

const router = express.Router();


router.post("/new-cart/", async (request, response) => {
    try {
        const cart = request.body;
        const newCart = await cartsLogic.addOneCart(cart);
        response.status(201).json(newCart);
    }
    catch (err) {
        response.status(500).json(err);
    }
});

router.get("/carts/:customerId", async (request, response) => {
    try {
        const customerId = request.params.customerId;
        //get the last shopping cart by customer id
        const lastCart = await cartsLogic.getLastCartByCustomerID(customerId);

        let responseMessage = {}
        if (lastCart !== null) {
            //checking if it is open cart (means cart exist but no order was placed) or closed cart (means for this last cart was placed order)
            const lastOrder = await ordersLogic.getLastOrderByCustomerIDAndCartID(lastCart.customerID, lastCart._id);
            if (lastOrder !== null) {
                
                responseMessage = {
                    newCustomer: false,
                    message: "closed-order",
                    lastCart: lastCart,
                    closedOrder: true
                }
            }
            else {
                let itemsOfCart = [];
                let sum = 0; 
                itemsOfCart = await itemLogic.getAllItemsByCartID(lastCart._id);
                for (i=0; i < itemsOfCart.length; i++){
                    sum += itemsOfCart[i].totalPrice;
                }
                responseMessage = {
                    newCustomer: false,
                    message: "open-order",
                    lastCart: lastCart,
                    closedOrder: false,
                    itemsSumInOpenCart:sum
                }
            }
        }
        else {
            responseMessage = {
                newCustomer: true,
                message: "No cart, new customer"
            }
        }
        response.json(responseMessage);

    }
    catch (err) {
        response.status(500).json(err);
    }
});



module.exports = router;