const models = require("../models/models");


async function addOneCart(cart){
    return new Promise((resolve, reject)=>{
        const newCart = new models.ShoppingCart(cart);
        newCart.save((err,responseCart)=>{
            if (err){
                reject(err);
            }
            else{
                resolve(responseCart)
            }
        });
    });
}

async function getLastCartByCustomerID(id){
    return new Promise((resolve, reject)=>{
        models.ShoppingCart.findOne({customerID: id}).sort({date:-1}).limit(1).exec((err,lastCart)=>{
            if (err){
                reject(err);
            }
            else{
                resolve(lastCart);

            }
        });
    });
}


module.exports = {
    addOneCart,
    getLastCartByCustomerID

}