const express = require("express");
const cors = require("cors");
const itemsController = require("./items/items-controller");
const productsController = require("./products/products-controller");
const customersController = require("./customers/customers-controller");
const ordersController = require("./orders/orders-controller");
const cartsController = require("./carts/carts-controller");
const productsCategoriesController = require("./productsCategories/productsCategories-controller");
const adminController = require("./admin/admin-controller");



const server = express();

server.use(cors());
server.use(express.json());
server.use('/uploads',express.static('uploads'));
server.use("/api/supermarket", itemsController);
server.use("/api/supermarket", productsController);
server.use("/api/supermarket", customersController);
server.use("/api/supermarket", ordersController);
server.use("/api/supermarket", cartsController);
server.use("/api/supermarket", productsCategoriesController);
server.use("/api/supermarket", adminController);




server.get("*",(request,response)=>{
    response.status(404).json({message: "Route not found."});
});

server.listen(3000, ()=>{
console.log("Listening on http://localhost:3000");
});
