const mongoose = require("mongoose");
mongoose.connect('mongodb://localhost:27017/Supermarket', {useNewUrlParser: true},(err,mongoClient)=>{
    if (err){
        console.log(err);
    }
    else{
        console.log("we are connected to " + mongoClient.name + " DB on mongoDB");
    }
});

module.exports = {
    mongoose
}
